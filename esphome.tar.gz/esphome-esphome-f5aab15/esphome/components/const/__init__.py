"""Constants used by esphome components."""

CODEOWNERS = ["@esphome/core"]

CONF_DRAW_ROUNDING = "draw_rounding"
CONF_REQUEST_HEADERS = "request_headers"
