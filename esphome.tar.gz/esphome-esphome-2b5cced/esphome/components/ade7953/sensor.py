import esphome.config_validation as cv

CONFIG_SCHEMA = cv.invalid(
    "The ade7953 sensor component has been renamed to ade7953_i2c."
)
