import esphome.codegen as cg

CODEOWNERS = ["@clydebarrow"]
DEPENDENCIES = ["i2c"]

axs15231_ns = cg.esphome_ns.namespace("axs15231")
